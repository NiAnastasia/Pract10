const anchors = document.querySelectorAll('a');
const ico = document.querySelectorAll('img.ico');
const slider__one =  document.querySelectorAll('.slider__one');
const slider__two =  document.querySelectorAll('.slider__two');
const radioOne =  document.querySelector('.radioOne');
const radioTwo =  document.querySelector('.radioTwo');
const about =  document.querySelectorAll('.brw');
let vWidth = document.documentElement.clientWidth;; //ширина вьюпорта


if(vWidth < 1000){
  document.querySelector('head meta[name=viewport]').setAttribute('content', 'width = 1000');
}
else if(vWidth > 1300){
  console.log("ширина"+vWidth);
}



for(let i = 0; i < ico.length; i++){
  ico[i].onmouseover = function(event){
    var target = event.target;
    target.style.backgroundColor = '#333333';
  }
}    

for(let i = 0; i < ico.length; i++){
  ico[i].onmouseout = function(event){
    var target = event.target;
    target.style.backgroundColor = '#656565';
  }
}  

anchors[0].onclick = function(e){
  e.preventDefault();
  window.location.hash = "Home";
}; 
anchors[1].onclick = function(e){
  e.preventDefault();
  window.location.hash = "About";
}; 
anchors[2].onclick = function(e){
  e.preventDefault();
  window.location.hash = "Portfolio_Showcase2";
}; 
anchors[3].onclick = function(e){
  e.preventDefault();
  window.location.hash = "Contact";
};

